public class Exercise12 {
    public static void main(String[] args) {
        String[] letters = { "A", "B", "C" };

        for (String letter : letters) {
            System.out.println(letter);
        }

    }

}
