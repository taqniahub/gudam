public class Example17 {
    public static void main(String[] args) {

        int i = 2;
        do {
            System.out.println("Even: " + i);
            i += 2;
        } while (i < 10);
    }
}
