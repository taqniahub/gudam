public class Example20 {
    public static final String MULTIPLY = "multiply";

    public static void main(String[] args) {
        System.out.println("The operation is " + MULTIPLY);
    }
}
