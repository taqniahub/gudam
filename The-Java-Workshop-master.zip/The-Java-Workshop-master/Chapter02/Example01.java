public class Example01 {
    public static void main(String[] args) {
        int x = 2;
        int y = 1;

        if ((x + y) < 5) {
            System.out.println("X added to Y is less than 5.");
        }
    }
}
