public class Main {
    public static void main(String[] args) {
        float f = 51.49f;
        System.out.println(f);
        int i = Math.round(f);
        System.out.println(i);
    }
}
