public class Main {
    public static void main(String[] args) {
        String t = "This is a text";
        char c = 'A';
        int i = 53;
        float f = 23.08f;
        double d = 1.97;
        boolean b = true;
        System.out.println(t);
        System.out.println(c);
        System.out.println(i);
        System.out.println(f);
        System.out.println(d);
        System.out.println(b);
    }
}
