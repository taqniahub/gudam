public class Main {
    public static void main(String[] args) {
        double a = 3;
        double b = 4;
        double h = 0;
        h = Math.sqrt(Math.pow(a,2) + Math.pow(b,2));
        System.out.println(h);
    }
}
