package com.packt.java.chapter13;

public class Exercise1 {

    public static void main(String[] args) {
        System.out.println(sum(2, 3));
        System.out.println(sum(2, 3));
        System.out.println(sum(2, 3));
    }

    static int sum(int price1, int price2) {
        return price1 + price2;
    }
}