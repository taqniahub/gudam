public class Example05 {
    public static void main(String[] args) {
        String vehicleType = null;
        String vehicle = "car";

        if (vehicle.equals(vehicleType)) {
            System.out.println("it's a car");
        } else {
            System.out.println("it's not a car");
        }
    }
}
