package com.packtpub.workflow;

public class EmailNotifier {
    public void sendFailureEmail(WorkflowStatus workflowStatus) {
        // This would have actual code...
    }
}
