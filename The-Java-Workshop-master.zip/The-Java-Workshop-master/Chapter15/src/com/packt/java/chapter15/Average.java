package com.packt.java.chapter15;

public class Average {

    public static void main(String[] args) {

//        OptionalDouble avg = IntStream.of(6, 3, 8, 12, 3, 9).average();
//        System.out.println(avg);

//        OptionalDouble avg = LongStream.of(6, 3, 8, 12, 3, 9).average();
//        System.out.println(avg);

//        OptionalDouble avg = DoubleStream.of(6, 3, 8, 12, 3, 9).average();
//        System.out.println(avg);

    }

}
