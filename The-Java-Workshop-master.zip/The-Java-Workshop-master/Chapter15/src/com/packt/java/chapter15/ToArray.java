package com.packt.java.chapter15;

public class ToArray {

    public static void main(String[] args) {

//        Object[] array = Stream.of(1, 4, 6, 2, 3, 7).toArray();

//        Integer[] array = Stream.of(1, 4, 6, 2, 3, 7).toArray(Integer[]::new);

//        Integer[] array = Stream.of(1, 4, 6, 2, 3, 7).toArray(elements -> new Integer[elements]);

    }

}
