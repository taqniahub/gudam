package com.packt.java.chapter15;

import java.util.PrimitiveIterator;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Spliterator {

    public static void main(String[] args) {

//        Stream.of(1, 2, 3, 4, 5)
//                .spliterator();
//        while (iterator.hasNext()) {
//            Integer next = iterator.next();
//            System.out.println(next);
//        }

    }

}
