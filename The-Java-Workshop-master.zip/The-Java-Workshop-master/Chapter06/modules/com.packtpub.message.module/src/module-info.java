module com.packtpub.message.module {
    requires com.packtpub.day.module;
}